# Personal Site & Project Blog
This will be my personal site and project blog.  Github pages is being utilized for hosting and Jekyll to create the site.

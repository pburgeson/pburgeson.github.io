---
layout: post
title: "Cable CNC Project Removal"
date: 2020-08-08
---
I have opted to remove the Cable CNC project.  I believe that I will get more value out of finding/paying for access to CNC equipment.  While I had hoped to expand it to a 3D system for a garadening robot, I have opted to work on a different project instead.  I want to instead begin work on the mini falcon 9, a project which has interested me for some time.